kill -9 $PPID
bin/java -m Main/Main.App