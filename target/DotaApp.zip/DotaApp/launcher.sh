#!/DotaApp/bin/sh
JLINK_VM_OPTIONS=
DIR=`dirname $0`
$DIR/bin/java $JLINK_VM_OPTIONS -m Main/Main.App $@
